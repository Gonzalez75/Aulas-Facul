﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ExChart
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            chart1.Series[0].Points.AddXY("jan", 15);
            chart1.Series[0].Points.AddXY("fev", 71);
            chart1.Series[0].Points.AddXY("mar", 22);
            chart1.Series[0].Points.AddXY("abr", 90);
            chart1.Series[0].Points.AddXY("mai", 3);
            chart1.Series[0].Points.AddXY("jun", 25);
            chart1.Series[0].Points.AddXY("jul", 41);
            chart1.Series[0].Points.AddXY("ago", 66);

            chart1.Series[1].Points.AddXY("jan", 17);
            chart1.Series[1].Points.AddXY("fev", 65);
            chart1.Series[1].Points.AddXY("mar", 33);
            chart1.Series[1].Points.AddXY("abr", 76);
            chart1.Series[1].Points.AddXY("mai", 10);
            chart1.Series[1].Points.AddXY("jun", 42);
            chart1.Series[1].Points.AddXY("jul", 56);
            chart1.Series[1].Points.AddXY("ago", 60);

        }
    }
}
