﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            String nome;
            int l,i;

            Console.Write("Digite seu nome completo: ");
            nome = Console.ReadLine();
            l = nome.Length;

            for (i = l - 1; nome[i] != ' '; --i) ;
            
            //           1         2
            // 012345678901234567890
            // Mauricio Neves Asenjo
            // o i esta valando 14
            
            Console.WriteLine("Sobrenome.........: " + nome.Substring(i + 1, l - i - 1));
            Console.WriteLine("Ref. Bibliografica: " + nome.Substring(i + 1, l - i - 1) + ", " + nome.Substring(0, i));
            Console.ReadKey();

        }
    }
}
