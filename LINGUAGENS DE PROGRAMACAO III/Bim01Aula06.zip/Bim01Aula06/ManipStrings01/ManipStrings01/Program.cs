﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ManipStrings
{
    class Program
    {
        static void Main(string[] args)
        {
            String st1;
            String st2;
            int l1;
            int l2;

            Console.Write("Digite uma palavra: ");
            st1 = Console.ReadLine();
            l1 = st1.Length;

            Console.Write("Digite outra palavra: ");
            st2 = Console.ReadLine();
            l2 = st2.Length;

            Console.WriteLine("A primeira palavra digitada tem " + l1 + " caracteres.");
            Console.WriteLine("A segunda  palavra digitada tem " + l2 + " caracteres.");
            Console.ReadKey();

            Console.WriteLine("Imprimindo na vertical");
            for (int i = 0; i < l1; ++i)
                Console.WriteLine(st1[i]);
            Console.ReadKey();

            if (st1 == st2)
                Console.WriteLine("As strings digitadas são iguais.");
            else
                Console.WriteLine("As strings digitadas são diferentes.");
            Console.ReadKey();

        }
    }
}
