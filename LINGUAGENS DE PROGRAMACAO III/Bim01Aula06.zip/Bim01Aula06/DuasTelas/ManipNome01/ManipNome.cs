﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManipNome01
{
    class ManipNome
    {
        private static String nome;

        public static void setNome(String _nome) { nome = _nome; }
        public static String getNome() { return nome; }
        public static int getUltimoEspaco()
        {
            int i;

            for (i = nome.Length - 1; nome[i] != ' '; --i) ;
            return i;
        }
        public static String getSobrenome()
        {
            return nome.Substring(getUltimoEspaco() + 1, nome.Length - getUltimoEspaco() - 1);
        }
        public static String getNomeF1()
        {
            return nome.Substring(getUltimoEspaco() + 1, nome.Length - getUltimoEspaco() - 1) + ", " + nome.Substring(0, getUltimoEspaco());
        }
        public static String getNomeF2()
        {
            return "blablabla";
        }
        public static String getNomeF3()
        {
            return "blablabla";
        }

    }
}
