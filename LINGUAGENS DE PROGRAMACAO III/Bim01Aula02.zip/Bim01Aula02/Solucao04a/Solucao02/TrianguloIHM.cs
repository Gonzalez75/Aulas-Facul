﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Solucao02
{
    public partial class TrianguloIHM : Form
    {
        public TrianguloIHM()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Triangulo umtriangulo = new Triangulo();
            umtriangulo.setB(textBox1.Text);
            umtriangulo.setH(textBox2.Text);
            textBox3.Text = umtriangulo.getArea();
        }

  
    }
}
