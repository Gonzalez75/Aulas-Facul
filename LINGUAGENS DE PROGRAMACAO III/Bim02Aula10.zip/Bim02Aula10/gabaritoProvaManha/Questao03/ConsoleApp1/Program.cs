﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        public static void validaDados(Prova _dupla)
        {
            Erro.setErro(false);
            if (_dupla.getNome1().Equals(""))
            {
                Erro.setErro("Nome1 é de preenchimento obrigatório.");
                return;
            }
            String[] aux1 = _dupla.getNome1().Split(' ');
            if (aux1.Length == 1)
            {
                Erro.setErro("Você deve digitar o nome completo para Nome1.");
                return;
            }

            if (_dupla.getNome2().Equals(""))
            {
                Erro.setErro("Nome2 é de preenchimento obrigatório.");
                return;
            }
            String[] aux2 = _dupla.getNome2().Split(' ');
            if (aux2.Length == 1)
            {
                Erro.setErro("Você deve digitar o nome completo para Nome2.");
                return;
            }
        }
        static void Main(string[] args)
        {
            Prova dupla = new Prova();
            dupla.setNome1("Maurício Neves Asenjo");
            dupla.setNome2("Fernando Ai Caramba Branquinho");
            validaDados(dupla);
            Console.WriteLine(Erro.getErro() ? Erro.getMens() : "Sucesso...");
        }
    }
}
