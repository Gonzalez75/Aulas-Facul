﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class Prova
    {
        private String nome1="";
        private String nome2="";

        public void setNome1(String _nome1) { nome1 = _nome1; }
        public void setNome2(String _nome2) { nome2 = _nome2; }
        public String getNome1() { return nome1; }
        public String getNome2() { return nome2; }

    }
}
