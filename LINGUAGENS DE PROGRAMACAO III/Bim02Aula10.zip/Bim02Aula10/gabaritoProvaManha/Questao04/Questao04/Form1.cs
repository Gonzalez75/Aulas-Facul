﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Questao04
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int y;

            chart1.Series[0].Points.Clear();
            for (int x = -100; x < 101; ++x)
            {
                y = 2 * x * x * x + 7 * x * x + 4 * x + 5;
                chart1.Series[0].Points.AddXY(x, y);
            }
        }
    }
}
