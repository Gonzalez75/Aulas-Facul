﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Questao04a
{
    class DoisNumeros
    {
        public int soma;
        public int produto;
    }
}
