﻿using System;

namespace Questao04a
{
    class Program
    {
        static DoisNumeros questaoQuatro(int _a, int _b)
        {
            DoisNumeros resultados = new DoisNumeros();

            resultados.soma = _a + _b;
            resultados.produto = _a * _b;
            return resultados;
        }
        static void Main(string[] args)
        {
            DoisNumeros resultados = new DoisNumeros();

            resultados = questaoQuatro(5, 7);
            Console.WriteLine("Soma    = " + resultados.soma);
            Console.WriteLine("Produto = " + resultados.produto);
        }
    }
}
