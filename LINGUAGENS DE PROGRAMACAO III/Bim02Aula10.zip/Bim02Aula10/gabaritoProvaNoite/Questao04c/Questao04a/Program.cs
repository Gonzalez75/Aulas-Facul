﻿using System;

namespace Questao04a
{
    class Program
    {
        static String questaoQuatro(int _a, int _b)
        {
            String resultados = ((_a + _b) + "," + (_a * _b));

            return resultados;
        }
        static void Main(string[] args)
        {
            String[] resultados = questaoQuatro(5, 7).Split(',');
            Console.WriteLine("Soma    = " + resultados[0]);
            Console.WriteLine("Produto = " + resultados[1]);
        }
    }
}
