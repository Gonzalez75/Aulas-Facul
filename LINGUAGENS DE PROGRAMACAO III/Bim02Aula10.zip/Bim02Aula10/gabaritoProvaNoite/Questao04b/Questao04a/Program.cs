﻿using System;

namespace Questao04a
{
    class Program
    {
        static int[] questaoQuatro(int _a, int _b)
        {
            int[] resultados = new int[2];

            resultados[0] = _a + _b;
            resultados[1] = _a * _b;
            return resultados;
        }
        static void Main(string[] args)
        {
            int[] resultados = new int[2];

            resultados = questaoQuatro(5, 7);
            Console.WriteLine("Soma    = " + resultados[0]);
            Console.WriteLine("Produto = " + resultados[1]);
        }
    }
}
