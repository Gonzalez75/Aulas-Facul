﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        public static void validaDados(Prova _valores)
        {
            Erro.setErro(false);
            if (_valores.getMinimo().Equals(""))
            {
                Erro.setErro("Minimo é de preenchimento obrigatório.");
                return;
            }
            else
            {
                try
                {
                    int.Parse(_valores.getMinimo());
                }
                catch
                {
                    Erro.setErro("Minimo deve ser numérico");
                    return;
                }
            }
            if (_valores.getMaximo().Equals(""))
            {
                Erro.setErro("Máximo é de preenchimento obrigatório.");
                return;
            }
            else
            {
                try
                {
                    int.Parse(_valores.getMaximo());
                }
                catch
                {
                    Erro.setErro("Máximo deve ser numérico");
                    return;
                }
            }

            if (int.Parse(_valores.getMaximo()) <= int.Parse(_valores.getMinimo()))
            {
                Erro.setErro("O valor do máximo deve ser maior que o mínimo.");
                return;
            }
        }
        static void Main(string[] args)
        {
            Prova valores = new Prova();
            valores.setMinimo("5");
            valores.setMaximo("12");
            validaDados(valores);
            Console.WriteLine(Erro.getErro() ? Erro.getMens() : "Sucesso...");
        }
    }
}
