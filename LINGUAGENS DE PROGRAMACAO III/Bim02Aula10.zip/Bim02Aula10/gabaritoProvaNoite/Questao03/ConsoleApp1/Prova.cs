﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class Prova
    {
        private String minimo="";
        private String maximo="";

        public void setMinimo(String _minimo) { minimo = _minimo; }
        public void setMaximo(String _maximo) { maximo = _maximo; }
        public String getMinimo() { return minimo; }
        public String getMaximo() { return maximo; }

    }
}
