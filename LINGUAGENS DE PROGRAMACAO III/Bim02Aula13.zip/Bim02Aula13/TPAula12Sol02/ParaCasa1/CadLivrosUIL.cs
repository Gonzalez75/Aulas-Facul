﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.Office.Interop.Word;

namespace ParaCasa1
{
    public partial class CadLivrosUIL : Form
    {
        public CadLivrosUIL()
        {
            InitializeComponent();
        }

        private void CadLivrosUIL_Load(object sender, EventArgs e)
        {
            LivroBLL.conecta();
            if (Erro.getErro())
            {
                MessageBox.Show(Erro.getMsg());
                System.Windows.Forms.Application.Exit();
            }
        }

        private void CadLivrosUIL_FormClosed(object sender, FormClosedEventArgs e)
        {
            LivroBLL.desconecta();
        }

         private void button1_Click(object sender, EventArgs e)
        {
             LivroBLL.getProximo();
             while (!Erro.getErro())
             {
                 listBox1.Items.Add("Titulo = " + Livro.getTitulo() + " escrito por " + Livro.getAutor());
                 LivroBLL.getProximo();
             }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Word.Application word = new Microsoft.Office.Interop.Word.Application();
            Document doc = word.Documents.Add();
            Selection texto = word.Selection;

            doc.Activate();
            LivroBLL.getProximo();
            while (!Erro.getErro())
            {
                texto.TypeText("Titulo = " + Livro.getTitulo() + " escrito por " + Livro.getAutor());
                texto.TypeParagraph();
                LivroBLL.getProximo();
            }

            doc.SaveAs(@"c:\matar\Aula12.doc");
            word.Documents.Close();
            word.Quit();
        }
    }
}
