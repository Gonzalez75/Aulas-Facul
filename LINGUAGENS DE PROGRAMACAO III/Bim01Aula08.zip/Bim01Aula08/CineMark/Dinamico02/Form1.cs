﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dinamico02
{
    public partial class Form1 : Form
    {
        Button[,] b = new Button[10,20];
        

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int linha = 20;
            int coluna = 20;
            char letra = 'A';

            for (int i = 0; i < 10; ++i)
            {
                for (int j = 0; j < 20; ++j)
                {
                    b[i,j] = new Button();
                    b[i,j].Name = "Botão" + letra + (j + 1);
                    b[i,j].Text =  "" + letra + (j + 1);
                    b[i,j].Location = new Point(coluna, linha);
                    b[i, j].BackColor = Color.Green;
                    b[i,j].Size = new System.Drawing.Size(40, 20);
                    coluna += 50;
                    Controls.Add(b[i,j]);
                }
                coluna = 20;
                linha += 30;
                ++letra;
            }
            
        }
    }
}
