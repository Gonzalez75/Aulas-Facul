﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Sender
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void metodoGenerico(object sender, EventArgs e)
        {
            if (sender == button1)
            {
                MessageBox.Show("Você pressionou o botão 1!");
            }
            else
            {
                if (sender == button2)
                {
                    MessageBox.Show("Você pressionou o botão 2!");
                }
                else
                {
                    MessageBox.Show("Você pressionou o botão 3!");
                }
            }
        }

 
    }
}
