﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Sender
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void metodoGenerico(object sender, EventArgs e)
        {
            Button aux = (Button)sender;
            MessageBox.Show("O botão pressionado foi " + aux.Text);
        }

 
    }
}
