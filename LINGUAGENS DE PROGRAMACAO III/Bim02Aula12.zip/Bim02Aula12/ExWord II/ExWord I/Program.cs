﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Office.Interop.Word;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Application word = new Application();
            Document doc = word.Documents.Open(@"c:\matar\teste.doc");
            Selection texto = word.Selection;

            doc.Activate();
            texto.TypeText(DateTime.Now.ToString());
            texto.TypeParagraph();
            texto.TypeText("Inserindo uma nova linha...");
            texto.TypeParagraph();
            doc.Save();
            
            word.Documents.Close();
            word.Quit();
        }
    }
}
