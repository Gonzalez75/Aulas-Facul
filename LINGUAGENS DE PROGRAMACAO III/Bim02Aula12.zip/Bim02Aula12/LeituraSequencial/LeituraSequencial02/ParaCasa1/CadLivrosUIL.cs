﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ParaCasa1
{
    public partial class CadLivrosUIL : Form
    {
        public CadLivrosUIL()
        {
            InitializeComponent();
        }

        private void CadLivrosUIL_Load(object sender, EventArgs e)
        {
            LivroBLL.conecta();
            if (Erro.getErro())
            {
                MessageBox.Show(Erro.getMsg());
                Application.Exit();
            }
        }

        private void CadLivrosUIL_FormClosed(object sender, FormClosedEventArgs e)
        {
            LivroBLL.desconecta();
        }

         private void button1_Click(object sender, EventArgs e)
        {
             LivroBLL.getProximo();
             while (!Erro.getErro())
             {
                 listBox1.Items.Add("Titulo = " + Livro.getTitulo() + " escrito por " + Livro.getAutor());
                 LivroBLL.getProximo();
             }

        }

    }
}
