﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

/*
 * Todos os campos são de preenchimento obrigatorio
 * Ano de edição deverá ser numérico e positivo
*/

namespace ParaCasa1
{
    class LivroBLL
    {
        public static void conecta()
        {
            LivroDAL.conecta();
        }

        public static void desconecta()
        {
            LivroDAL.desconecta();
        }

        public static DataTable getDT()
        {
            return LivroDAL.getDT();
        }


    }
}

