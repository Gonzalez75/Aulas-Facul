﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex01
{
    class Program
    {
        static void Main(string[] args)
        {
            float b, h, a;

            Console.Write("Base do Triangulo...: ");
            b = float.Parse(Console.ReadLine());
            Console.Write("Altura do Triangulo.: ");
            h = float.Parse(Console.ReadLine());
            a = b * h / 2;
            Console.WriteLine("Area do Triangulo = " + a);
            Console.ReadKey();
        }
    }
}
