﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dinamico02
{
    public partial class Form1 : Form
    {
        Button[] b = new Button[10];
        char letra = 'A'; // 0100 0001 em decimal 65 e em hexa 41

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object cachorrinho, EventArgs peludinho)
        {
            for (int i = 0; i < 10; ++i)
            {
                b[i] = new Button();
                b[i].Name = "Botão " + (i + 1);
                b[i].Text = "Botão " + letra + (i + 1);
                b[i].Location = new Point(99, 30 * (i + 1));
                ++letra;
                Controls.Add(b[i]);
            }
        }
    }
}
