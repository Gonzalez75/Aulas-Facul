﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dinamicos01
{
    public partial class Form1 : Form
    {
        Label l1;
        Label l2;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            l1 = new Label();
            l2 = new Label();

            l1.Name = "l1";
            l1.Text = "Santa";
            l1.Location = new Point(23, 99);
            l1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));


            l2.Name = "l2";
            l2.Text = " Cecilia";
            l2.Location = new Point(123, 99);
            l2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));

            Controls.Add(l1);
            Controls.Add(l2);
        }
    }
}
